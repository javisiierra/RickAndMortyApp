package com.example.rickandmorty.modelo;

import java.io.Serializable;

public class Location implements Serializable {
    private String name;
    private String url;
}
